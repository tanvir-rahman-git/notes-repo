package interfaces;

import classes.*;

public interface IQuantity{
	boolean addQuantity(int amount);
	boolean sellQuantity(int amount);
}