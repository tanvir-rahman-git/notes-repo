public class Bank
{
	private String bankName;
	private Account[] acc;
	
	public Bank(String bankName)
	{
		this.bankName=bankName;
		acc=new Account[100];
	}
	
	boolean insertAccount(Account A)
	{
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] == null)
			{
				acc[i]=A;
				return true;
			}
		}
		return false;
	}
	boolean removeAccount(Account A)
	{
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] == A)
			{
				acc[i] = null;
				return true;
			}
		}
		return false;
	}
	Account searchAccount(String id)
	{
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] != null)
			{
				if(acc[i].getId().equals(id))
				{
					return acc[i];
				}
			}
		}
		return null;
	}
	void showAllAccount()
	{
		for(int i=0; i<acc.length; i++)
		{
			if(acc[i] != null)
			{
				acc[i].show();
			}
		}
	}
}
