public class BankMain
{
	public static void main(String[] args)
	{
		
		
		Account a1=new Account("11A","Mr. X",293);
		Account a2=new Account("12A","Ms. ABC",239493);
		Account a3=new Account("13A","Mr. XYZ",2593);
		Account a4=new Account("14A","bhjhjhBC",2393);
		Account a5=new Account("15A","AhjhjBC",509493);
	    Bank b1=new Bank("NCC");
		
		
        System.out.println("-------------------------------------------------------");
		if(b1.insertAccount(a1)){System.out.println("Account Insertted");}
		else{System.out.println("Can NOT be Inserted");}
		
		if(b1.insertAccount(a2)){System.out.println("Account Insertted");}
		else{System.out.println("Can NOT be Inserted");}
		
		if(b1.insertAccount(a3)){System.out.println("Account Insertted");}
		else{System.out.println("Can NOT be Inserted");}
		
		if(b1.insertAccount(a4)){System.out.println("Account Insertted");}
		else{System.out.println("Can NOT be Inserted");}
		
		if(b1.insertAccount(a5)){System.out.println("Account Insertted");}
		else{System.out.println("Can NOT be Inserted");}
		b1.showAllAccount();
		
		if(b1.removeAccount(a2)){System.out.println("Book Removed");}
		else{System.out.println("Can NOT be Removed");}
		b1.showAllAccount();
		

	    Account A = b1.searchAccount("11A");
		
		if(A!= null)
		{
			System.out.println("Object Found....");
			A.show();
		}
		else
		{
			System.out.println("Object NOT Found....");
		}
	}
}