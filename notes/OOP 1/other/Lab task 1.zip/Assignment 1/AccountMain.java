public class AccountMain{
	
	public static void main(String[] args)
{       Account x1= new Account();
		Account y1= new Account(123279543,"My Account",25,"Bangladeshi",99999.99,555569);
		y1.show();
		x1.Value(455969553,"Sender",30,"Bangladeshi",55555.55,666642);
		x1.show();
	}
}