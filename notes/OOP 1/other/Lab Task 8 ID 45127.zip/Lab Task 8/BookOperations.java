import java.lang.*;


    public interface BookOperations
    {
	    public void addQuantity(int amount);
	    public void sellQuantity(int amount);
	    public void showDetails();
    }
