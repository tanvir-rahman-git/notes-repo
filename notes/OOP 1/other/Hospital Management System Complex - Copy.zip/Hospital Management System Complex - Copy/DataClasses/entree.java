package DataClasses;



public abstract class entree 
{
    public String EntryID;
    public String EntryName;
    public String EntryGender;
    public abstract void get_info();
        
    
    public abstract void out_info();
        
    
}   

