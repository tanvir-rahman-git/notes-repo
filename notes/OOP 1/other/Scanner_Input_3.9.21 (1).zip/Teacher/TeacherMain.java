public class TeacherMain
{
	public static void main(String[] args)
	{
		Teacher t1=new Teacher();
		t1.setValues();
		t1.show();
	}
}